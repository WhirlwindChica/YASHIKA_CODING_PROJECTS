import java.sql.*;
import javax.swing.*;
import javax.swing.table.*;
        
public class Email extends javax.swing.JFrame {

    String userid,username,Email;
    /**
     * Creates new form Email
     */
    public Email() {
      
        initComponents();
    }
public void setuserid(String u, String un)
{
    userid = u;
    username = un;
    msg.setText("Welcome ! "+un);
}
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        msg = new javax.swing.JLabel();
        Inbox = new javax.swing.JButton();
        Sent = new javax.swing.JButton();
        Draft = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        Compose = new javax.swing.JButton();
        Exit = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        draftemail = new javax.swing.JButton();
        INBOXDetails = new javax.swing.JButton();
        sentemail = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        msg.setFont(new java.awt.Font("Tahoma", 1, 36)); // NOI18N
        msg.setForeground(new java.awt.Color(255, 255, 204));
        msg.setText("Welcome");
        getContentPane().add(msg, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 40, 700, 40));

        Inbox.setFont(new java.awt.Font("Tahoma", 1, 36)); // NOI18N
        Inbox.setForeground(new java.awt.Color(0, 51, 255));
        Inbox.setText("INBOX");
        Inbox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                InboxActionPerformed(evt);
            }
        });
        getContentPane().add(Inbox, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 190, 170, 60));

        Sent.setFont(new java.awt.Font("Tahoma", 1, 36)); // NOI18N
        Sent.setForeground(new java.awt.Color(0, 153, 0));
        Sent.setText("SENT");
        Sent.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SentActionPerformed(evt);
            }
        });
        getContentPane().add(Sent, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 440, 170, -1));

        Draft.setFont(new java.awt.Font("Tahoma", 1, 36)); // NOI18N
        Draft.setForeground(new java.awt.Color(255, 0, 51));
        Draft.setText("DRAFT");
        Draft.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DraftActionPerformed(evt);
            }
        });
        getContentPane().add(Draft, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 670, 170, -1));

        jTable1.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 14))); // NOI18N
        jTable1.setFont(new java.awt.Font("Tahoma", 2, 18)); // NOI18N
        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Sender", "Receiver", "Subject", "Date/Time"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, true, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jTable1.getTableHeader().setReorderingAllowed(false);
        jScrollPane1.setViewportView(jTable1);
        if (jTable1.getColumnModel().getColumnCount() > 0) {
            jTable1.getColumnModel().getColumn(0).setResizable(false);
        }

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 130, 1420, 710));

        Compose.setFont(new java.awt.Font("Tahoma", 1, 36)); // NOI18N
        Compose.setText("COMPOSE");
        Compose.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ComposeActionPerformed(evt);
            }
        });
        getContentPane().add(Compose, new org.netbeans.lib.awtextra.AbsoluteConstraints(640, 890, -1, 60));

        Exit.setFont(new java.awt.Font("Tahoma", 1, 36)); // NOI18N
        Exit.setForeground(new java.awt.Color(255, 51, 51));
        Exit.setText("EXIT");
        Exit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ExitActionPerformed(evt);
            }
        });
        getContentPane().add(Exit, new org.netbeans.lib.awtextra.AbsoluteConstraints(1170, 880, 210, 60));

        jLabel4.setFont(new java.awt.Font("Tahoma", 3, 48)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 204, 51));
        jLabel4.setText("E-MAIL");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(1000, 30, 250, 50));

        draftemail.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        draftemail.setForeground(new java.awt.Color(255, 0, 51));
        draftemail.setText("VIEW DRAFT EMAILS");
        draftemail.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                draftemailActionPerformed(evt);
            }
        });
        getContentPane().add(draftemail, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 750, 300, 50));

        INBOXDetails.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        INBOXDetails.setForeground(new java.awt.Color(51, 0, 255));
        INBOXDetails.setText("VIEW INBOX EMAILS");
        INBOXDetails.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                INBOXDetailsActionPerformed(evt);
            }
        });
        getContentPane().add(INBOXDetails, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 280, 300, 50));

        sentemail.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        sentemail.setForeground(new java.awt.Color(0, 153, 0));
        sentemail.setText("VIEW SENT EMAILS");
        sentemail.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                sentemailActionPerformed(evt);
            }
        });
        getContentPane().add(sentemail, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 520, 300, 50));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/paris.jpg"))); // NOI18N
        jLabel1.setText("jLabel1");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(-620, -60, 2620, 1460));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void InboxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_InboxActionPerformed
      try
        {
            Class.forName("java.sql.DriverManager");
            Connection con = (Connection)DriverManager.getConnection("jdbc:mysql://localhost/Major","root","1234");
            Statement stmt = (Statement) con.createStatement();
            Email = "";
            String Q = "Select Email From Employee Where Empid="+userid+";";
            ResultSet rs = stmt.executeQuery(Q);
            if(rs.next())
                Email = rs.getString(1);
            
            String query="Select Sender,Receiver,Subject,Mdate From Mail Where Receiver='"+Email+"' and Status='Success';";
            rs = stmt.executeQuery(query);
            // Designed table - jTable1
            // Designed table any editing possible through DefaultTableModel class object
            // model - Object of DefaultTableModel using jTable Model using getModel() function
            DefaultTableModel model =(DefaultTableModel)jTable1.getModel();
            
            // Check table pre-existing row or not If row exist then while condition is true
            while(model.getRowCount()>0)   // getRowCount() - return number of filled row/empty row
            {
                model.removeRow(0);   // Remove First Row
            }
            // Check ResultSet object (rs) record exist or not and also move to next record
            while(rs.next())
            {         // Result Set Object Row Content Add into Table Row using DefaultTableModel object(model)
                      model.addRow(new Object[]{rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4)});
            }
            
            stmt.close();
            rs.close();
            con.close();
        }
        catch(Exception e)
        {
            JOptionPane.showMessageDialog(this, e.getMessage());
        }
    }//GEN-LAST:event_InboxActionPerformed

    private void SentActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SentActionPerformed
        try
        {
            Class.forName("java.sql.DriverManager");
            Connection con = (Connection)DriverManager.getConnection("jdbc:mysql://localhost/Major","root","1234");
            Statement stmt = (Statement) con.createStatement();
            Email = "";
            String Q = "Select Email From Employee Where Empid="+userid+";";
            ResultSet rs = stmt.executeQuery(Q);
            if(rs.next())
                Email = rs.getString(1);
            
            String query="Select Sender,Receiver,Subject,Mdate From Mail Where Sender='"+Email+"' And Status ='Success'";
            rs = stmt.executeQuery(query);
            DefaultTableModel model =(DefaultTableModel)jTable1.getModel();
            while(model.getRowCount()>0)
            {
                model.removeRow(0);
            }
            while(rs.next())
            {                
                model.addRow(new Object[]{rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4)});
            }
            stmt.close();
            rs.close();
            con.close();
        }
        catch(Exception e)
        {
            JOptionPane.showMessageDialog(this, e.getMessage());
        }
    }//GEN-LAST:event_SentActionPerformed

    private void DraftActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DraftActionPerformed
      try
        {
            Class.forName("java.sql.DriverManager");
            Connection con = (Connection)DriverManager.getConnection("jdbc:mysql://localhost/major","root","1234");
            Statement stmt = (Statement) con.createStatement();
            Email = "";
            String Q = "Select Email From Employee Where Empid="+userid+";";
            ResultSet rs = stmt.executeQuery(Q);
            if(rs.next())
                Email = rs.getString(1);
            
            String query="Select Sender,Receiver,Subject,Mdate From Mail Where Sender='"+Email+"' And Status='Draft'";
            rs = stmt.executeQuery(query);
            DefaultTableModel model =(DefaultTableModel)jTable1.getModel();
            while(model.getRowCount()>0)
            {
                model.removeRow(0);
            }
            while(rs.next())
            {                
                model.addRow(new Object[]{rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4)});
            }
            stmt.close();
            rs.close();
            con.close();
        }
        catch(Exception e)
        {
            JOptionPane.showMessageDialog(this, e.getMessage());
        }
    }//GEN-LAST:event_DraftActionPerformed

    private void ComposeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ComposeActionPerformed
     try
        {
            Class.forName("java.sql.DriverManager");
            Connection con = (Connection)DriverManager.getConnection("jdbc:mysql://localhost/Major","root","1234");
            Statement stmt = (Statement) con.createStatement();
            Email = "";
            String Q = "Select Email From Employee Where Empid="+userid+";";
            ResultSet rs = stmt.executeQuery(Q);
            if(rs.next())
                Email = rs.getString(1);
            
            stmt.close();
            rs.close();
            con.close();
        }
        catch(Exception e)
        {
            JOptionPane.showMessageDialog(this, e.getMessage());
        }
    Compose C = new Compose();
    C.setUser(Email);
    C.setVisible(true);
            
    }//GEN-LAST:event_ComposeActionPerformed

    private void ExitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ExitActionPerformed
       Home obj = new Home();
       obj.setUser(userid,username);
       obj.setVisible(true);
       this.setVisible(false);
    }//GEN-LAST:event_ExitActionPerformed

    private void INBOXDetailsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_INBOXDetailsActionPerformed
 
     try
        {
            Class.forName("java.sql.DriverManager");
            Connection con = (Connection)DriverManager.getConnection("jdbc:mysql://localhost/Major","root","1234");
            Statement stmt = (Statement) con.createStatement();
            Email = "";
            String Q = "Select Email From Employee Where Empid="+userid+";";
            ResultSet rs = stmt.executeQuery(Q);
            if(rs.next())
                Email = rs.getString(1);
            
            stmt.close();
            rs.close();
            con.close();
        }
        catch(Exception e)
        {
            JOptionPane.showMessageDialog(this, e.getMessage());
        }
        VIEW_INBOX obj = new VIEW_INBOX();
        obj.setUserId(Email);
        obj.setVisible(true);
    }//GEN-LAST:event_INBOXDetailsActionPerformed

    private void sentemailActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_sentemailActionPerformed
        try
        {
            Class.forName("java.sql.DriverManager");
            Connection con = (Connection)DriverManager.getConnection("jdbc:mysql://localhost/Major","root","1234");
            Statement stmt = (Statement) con.createStatement();
            Email = "";
            String Q = "Select Email From Employee Where Empid="+userid+";";
            ResultSet rs = stmt.executeQuery(Q);
            if(rs.next())
                Email = rs.getString(1);
            
            stmt.close();
            rs.close();
            con.close();
        }
        catch(Exception e)
        {
            JOptionPane.showMessageDialog(this, e.getMessage());
        }
        VIEW_SENT obj = new VIEW_SENT();
        obj.setUserId(Email);
        obj.setVisible(true);
    }//GEN-LAST:event_sentemailActionPerformed

    private void draftemailActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_draftemailActionPerformed
        try
        {
            Class.forName("java.sql.DriverManager");
            Connection con = (Connection)DriverManager.getConnection("jdbc:mysql://localhost/Major","root","1234");
            Statement stmt = (Statement) con.createStatement();
            Email = "";
            String Q = "Select Email From Employee Where Empid="+userid+";";
            ResultSet rs = stmt.executeQuery(Q);
            if(rs.next())
                Email = rs.getString(1);
            
            stmt.close();
            rs.close();
            con.close();
        }
        catch(Exception e)
        {
            JOptionPane.showMessageDialog(this, e.getMessage());
        }
        VIEW_DRAFT obj = new VIEW_DRAFT();
        obj.setUserId(Email);
        obj.setVisible(true);
                                           
    }//GEN-LAST:event_draftemailActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Email.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Email.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Email.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Email.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Email().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Compose;
    private javax.swing.JButton Draft;
    private javax.swing.JButton Exit;
    private javax.swing.JButton INBOXDetails;
    private javax.swing.JButton Inbox;
    private javax.swing.JButton Sent;
    private javax.swing.JButton draftemail;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JLabel msg;
    private javax.swing.JButton sentemail;
    // End of variables declaration//GEN-END:variables
}
