import java.sql.*;
import javax.swing.*;
import javax.swing.table.*;
        
public class AdminEmail extends javax.swing.JFrame {

    String userid,username,email;
    /**
     * Creates new form Email
     */
    public AdminEmail() {
      
        initComponents();
    }
public void setuserid(String u, String un)
{
    userid = u;
    username = un;
    msg.setText("Welcome ! "+username);
}
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        msg = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jButton4 = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        INBOXDetails = new javax.swing.JButton();
        sentemail = new javax.swing.JButton();
        draftemail = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        msg.setFont(new java.awt.Font("Tahoma", 1, 36)); // NOI18N
        msg.setForeground(new java.awt.Color(255, 255, 204));
        msg.setText("Welcome");
        getContentPane().add(msg, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 50, 700, 40));

        jButton1.setFont(new java.awt.Font("Tahoma", 1, 36)); // NOI18N
        jButton1.setForeground(new java.awt.Color(51, 0, 255));
        jButton1.setText("INBOX");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 210, 190, 60));

        jButton2.setFont(new java.awt.Font("Tahoma", 1, 36)); // NOI18N
        jButton2.setForeground(new java.awt.Color(0, 153, 51));
        jButton2.setText("SENT");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 430, 190, 60));

        jButton3.setFont(new java.awt.Font("Tahoma", 1, 36)); // NOI18N
        jButton3.setForeground(new java.awt.Color(255, 51, 51));
        jButton3.setText("DRAFT");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 640, 190, 60));

        jTable1.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 14))); // NOI18N
        jTable1.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Sender", "Receiver", "Subject", "Date/Time"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, true, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(jTable1);
        if (jTable1.getColumnModel().getColumnCount() > 0) {
            jTable1.getColumnModel().getColumn(0).setResizable(false);
        }

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 170, 1270, 680));

        jButton4.setFont(new java.awt.Font("Tahoma", 1, 36)); // NOI18N
        jButton4.setText("COMPOSE");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton4, new org.netbeans.lib.awtextra.AbsoluteConstraints(720, 860, -1, 60));

        jButton5.setFont(new java.awt.Font("Tahoma", 1, 36)); // NOI18N
        jButton5.setForeground(new java.awt.Color(255, 0, 0));
        jButton5.setText("EXIT");
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton5, new org.netbeans.lib.awtextra.AbsoluteConstraints(1270, 870, 200, 60));

        jLabel4.setBackground(new java.awt.Color(0, 0, 0));
        jLabel4.setFont(new java.awt.Font("Tahoma", 3, 48)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 204, 0));
        jLabel4.setText("ADMIN E-MAIL");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(920, 40, 440, -1));

        jLabel1.setText("jLabel1");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(-10, -20, -1, -1));

        INBOXDetails.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        INBOXDetails.setForeground(new java.awt.Color(0, 0, 255));
        INBOXDetails.setText("VIEW INBOX EMAILS");
        INBOXDetails.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                INBOXDetailsActionPerformed(evt);
            }
        });
        getContentPane().add(INBOXDetails, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 290, 300, 50));

        sentemail.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        sentemail.setForeground(new java.awt.Color(0, 153, 0));
        sentemail.setText("VIEW SENT EMAILS");
        sentemail.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                sentemailActionPerformed(evt);
            }
        });
        getContentPane().add(sentemail, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 510, 300, 50));

        draftemail.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        draftemail.setForeground(new java.awt.Color(255, 0, 0));
        draftemail.setText("VIEW DRAFT EMAILS");
        draftemail.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                draftemailActionPerformed(evt);
            }
        });
        getContentPane().add(draftemail, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 710, 300, 50));

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/paris.jpg"))); // NOI18N
        jLabel2.setText("jLabel2");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(-620, -60, 2570, 1490));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        try
        {
            Class.forName("java.sql.DriverManager");
            Connection con = (Connection)DriverManager.getConnection("jdbc:mysql://localhost/Major","root","1234");
            Statement stmt = (Statement) con.createStatement();
            email = "";
            String Q = "Select Email From Employee Where Empid="+userid+";";
            ResultSet rs = stmt.executeQuery(Q);
            if(rs.next())
                email = rs.getString(1);String query="Select Sender,Receiver,Subject,Mdate From Mail Where Receiver='"+email+"' and Status='Success'";
            rs = stmt.executeQuery(query);
            DefaultTableModel model =(DefaultTableModel)jTable1.getModel();
            
            while(model.getRowCount()>0)
            {
                model.removeRow(0);
            }
            while(rs.next())
            {             
                model.addRow(new Object[]{rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4)});
            }
            stmt.close();
            rs.close();
            con.close();
        }
        catch(Exception e)
        {
            JOptionPane.showMessageDialog(this, e.getMessage());
        }
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        try
        {
            Class.forName("java.sql.DriverManager");
            Connection con = (Connection)DriverManager.getConnection("jdbc:mysql://localhost/Major","root","1234");
            Statement stmt = (Statement) con.createStatement();
            email = "";
            String Q = "Select Email From Employee Where Empid="+userid+";";
            ResultSet rs = stmt.executeQuery(Q);
            if(rs.next())
                email = rs.getString(1);
            String query="Select Sender,Receiver,Subject,Mdate From Mail Where Sender='"+email+"' And Status ='Success'";
            rs = stmt.executeQuery(query);
            DefaultTableModel model =(DefaultTableModel)jTable1.getModel();
            while(model.getRowCount()>0)
            {
                model.removeRow(0);
            }
            while(rs.next())
            {                
                model.addRow(new Object[]{rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4)});
            }
            stmt.close();
            rs.close();
            con.close();
        }
        catch(Exception e)
        {
            JOptionPane.showMessageDialog(this, e.getMessage());
        }
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
      try
        {
            Class.forName("java.sql.DriverManager");
            Connection con = (Connection)DriverManager.getConnection("jdbc:mysql://localhost/major","root","1234");
            Statement stmt = (Statement) con.createStatement();
            String query="Select Sender,Receiver,Subject,Mdate From Mail Where Sender='"+email+"' And Status='Draft';";
            ResultSet rs = stmt.executeQuery(query);
            DefaultTableModel model =(DefaultTableModel)jTable1.getModel();
            while(model.getRowCount()>0)
            {
                model.removeRow(0);
            }
            while(rs.next())
            {                
                model.addRow(new Object[]{rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4)});
            }
            stmt.close();
            rs.close();
            con.close();
        }
        catch(Exception e)
        {
            JOptionPane.showMessageDialog(this, e.getMessage());
        }
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
    Compose C = new Compose();
    email=userid;
    C.setUser(email);
    C.setVisible(true);
            
    }//GEN-LAST:event_jButton4ActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
       AdminMenu obj = new AdminMenu();
       obj.setUser(userid,username);
       obj.setVisible(true);
       this.setVisible(false);
    }//GEN-LAST:event_jButton5ActionPerformed

    private void INBOXDetailsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_INBOXDetailsActionPerformed

        try
        {
            Class.forName("java.sql.DriverManager");
            Connection con = (Connection)DriverManager.getConnection("jdbc:mysql://localhost/Major","root","1234");
            Statement stmt = (Statement) con.createStatement();
            email = "";
            String Q = "Select Email From Employee Where Empid="+userid+";";
            ResultSet rs = stmt.executeQuery(Q);
            if(rs.next())
            {
                email = rs.getString(1);
            }

            stmt.close();
            rs.close();
            con.close();
        }
        catch(Exception e)
        {
            JOptionPane.showMessageDialog(this, e.getMessage());
        }
        VIEW_INBOX obj = new VIEW_INBOX();
        obj.setUserId(email);
        obj.setVisible(true);
    }//GEN-LAST:event_INBOXDetailsActionPerformed

    private void sentemailActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_sentemailActionPerformed
        try
        {
            Class.forName("java.sql.DriverManager");
            Connection con = (Connection)DriverManager.getConnection("jdbc:mysql://localhost/Major","root","1234");
            Statement stmt = (Statement) con.createStatement();
            email = "";
            String Q = "Select Email From Employee Where Empid="+userid+";";
            ResultSet rs = stmt.executeQuery(Q);
            if(rs.next())
            email = rs.getString(1);

            stmt.close();
            rs.close();
            con.close();
        }
        catch(Exception e)
        {
            JOptionPane.showMessageDialog(this, e.getMessage());
        }
        VIEW_SENT obj = new VIEW_SENT();
        obj.setUserId(email);
        obj.setVisible(true);
    }//GEN-LAST:event_sentemailActionPerformed

    private void draftemailActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_draftemailActionPerformed
        try
        {
            Class.forName("java.sql.DriverManager");
            Connection con = (Connection)DriverManager.getConnection("jdbc:mysql://localhost/Major","root","1234");
            Statement stmt = (Statement) con.createStatement();
            email = "";
            String Q = "Select Email From Employee Where Empid="+userid+";";
            ResultSet rs = stmt.executeQuery(Q);
            if(rs.next())
            email = rs.getString(1);

            stmt.close();
            rs.close();
            con.close();
        }
        catch(Exception e)
        {
            JOptionPane.showMessageDialog(this, e.getMessage());
        }
        VIEW_DRAFT obj = new VIEW_DRAFT();
        obj.setUserId(email);
        obj.setVisible(true);

    }//GEN-LAST:event_draftemailActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Email.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Email.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Email.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Email.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new AdminEmail().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton INBOXDetails;
    private javax.swing.JButton draftemail;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JLabel msg;
    private javax.swing.JButton sentemail;
    // End of variables declaration//GEN-END:variables
}
